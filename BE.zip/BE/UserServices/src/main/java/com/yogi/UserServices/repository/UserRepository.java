package com.yogi.UserServices.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.yogi.UserServices.model.User;

public interface UserRepository extends MongoRepository<User, String> {

}
