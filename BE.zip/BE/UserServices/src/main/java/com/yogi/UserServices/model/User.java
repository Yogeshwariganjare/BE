package com.yogi.UserServices.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.aggregation.ConvertOperators.ToString;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Users")

public class User {
	
	@Id
	private int adults;
	private int age;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	


}
	public String getUserId() {
		// TODO Auto-generated method stub
		return null;
	}
	}