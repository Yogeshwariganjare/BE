package com.yogi.ReservationService.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yogi.ReservationService.model.Reservation;
import com.yogi.ReservationService.repository.ReservationRepository;

@Service
public class ReservationService {

	@Autowired
	private ReservationRepository reservationRepository;
	
	public List<Reservation> getTicketsDetails()
	{
		return reservationRepository.findAll();
	}

	public Reservation addReservation(Reservation reserve) {
		// TODO Auto-generated method stub
		return reservationRepository.insert(reserve);
	}

	public Optional<Reservation> findById(String id) {
		// TODO Auto-generated method stub
		return reservationRepository.findById(id);
	}

	public Reservation update(Reservation order) {

		return reservationRepository.save(order);
	}

	public String deleteTicketById(String id) {
		reservationRepository.deleteById(id);
		return "Reservation Cancelled for Id: "+id;
	}



}
