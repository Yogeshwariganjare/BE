package com.yogi.ReservationService.resources;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.yogi.ReservationService.model.Reservation;
import com.yogi.ReservationService.repository.ReservationRepository;
import com.yogi.ReservationService.service.ReservationService;

@RestController
@RequestMapping("/reserve")
@CrossOrigin("http://localhost:4200/")
public class ReservationController {
	
	
	@Autowired
	ReservationService service;
	@Autowired
	RestTemplate restTemplate;
	
	@PostMapping("/addTicket")
	public Reservation saveTicket1(@RequestBody Reservation reserve) 
	{
		return service.addReservation(reserve);
		//return "Reserved ticket with id :  " + reserve.getId();
    }
	
	@GetMapping("/getAllTicketsDetails")
	public List<Reservation> getTicketsDetails()
	{
		return service.getTicketsDetails();	
	}
	
	@GetMapping("/{id}")
	public Optional<Reservation> getTickets(@PathVariable String id)
	{
		return service.findById(id);
	}
	
	
	@PutMapping("/update/{id}")
	public Reservation updateTicket(@RequestBody Reservation order ) 
	{
		return service.update(order);
	}
		
	 @DeleteMapping("/del/{id}")
	 public String deleteOrder (@PathVariable("id") String id)
	 {
		 service.deleteTicketById(id);
         return "Ticket deleted with id : "+service.deleteTicketById(id);
	}
}
