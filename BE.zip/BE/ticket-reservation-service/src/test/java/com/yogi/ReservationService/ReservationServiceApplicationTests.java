package com.yogi.ReservationService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.yogi.ReservationService.model.Reservation;
import com.yogi.ReservationService.repository.ReservationRepository;
import com.yogi.ReservationService.service.ReservationService;


@SpringBootTest
class ReservationServiceApplicationTests {

	@Autowired
	private ReservationService reservationService;
	
	@MockBean
	private ReservationRepository reservationRepository;

		@Test
		public void saveTrainTest() {
			Reservation reservation = new Reservation();
			when(reservationRepository.save(reservation)).thenReturn(reservation);
			assertEquals(reservation, reservationService.getTicketsDetails());
		
		}
		
	
	

}
