package com.yogi.APIgatewayzuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class APIGatewayZuulApplicationTests {

	@Test
	void contextLoads() {
	}

}
