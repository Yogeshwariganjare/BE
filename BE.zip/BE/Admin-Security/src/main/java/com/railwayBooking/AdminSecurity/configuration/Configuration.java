package com.railwayBooking.AdminSecurity.configuration;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.railwayBooking.AdminSecurity.services.JWTFilterRequest;
import com.railwayBooking.AdminSecurity.services.AdminService;

@SuppressWarnings("deprecation")
@EnableWebSecurity
public class Configuration extends WebSecurityConfigurerAdapter  {
	
	private static final String DEPRECATION = "deprecation";

	private static final String DEPRECATION2 = DEPRECATION;

	@Autowired
	private AdminService userService;
	
	@Autowired
	private JWTFilterRequest jwtFilterRequest  ;
	
	
	//congif authentication manager builder
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userService);
	}
	
	//config authentication manager builder
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf()
		.disable()
		.authorizeRequests()
		.antMatchers("/subs","/auth")
		.permitAll()
		.anyRequest()
		.authenticated();
		http.addFilterBefore(jwtFilterRequest, UsernamePasswordAuthenticationFilter.class);
	}
	
	//password encoder
	@SuppressWarnings(DEPRECATION2)
	@Bean
	public PasswordEncoder passwordEncoder()
	{
		return NoOpPasswordEncoder.getInstance();	
	}
	
	//congif authentication manager
	@Override
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		// TODO Auto-generated method stub
		return super.authenticationManagerBean();
	}
}