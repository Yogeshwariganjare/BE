package com.yogi.AdminService.repository;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.yogi.AdminService.model.Admin;

public interface AdminRepository extends MongoRepository<Admin, String>{

	

}
